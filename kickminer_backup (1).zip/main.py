import os
os.system("python -u api.py")