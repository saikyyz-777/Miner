import os
# os.system("python main.py")  <-- O minerador está pausado aqui
os.system("python -u api.py")